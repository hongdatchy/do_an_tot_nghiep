package com.bikesharedemo.login;

public class testClass {
    public static int a = 0;
}
