package com.bikesharedemo.login;

public class Common {

//    public static final String DOMAIN = "171.224.39.35";
    public static final String DOMAIN = "155.248.164.224";
    public static final String SERVER_PORT = "8080";
}
