package com.bikesharedemo.login;

public class checkSocketClose {
    public static String checksocket;
}
