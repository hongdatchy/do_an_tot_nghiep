package com.bikesharedemo.login;

import org.json.JSONArray;

public class GlobalVariables {
    public static JSONArray coor = new JSONArray();
    public static String token = null;
}
